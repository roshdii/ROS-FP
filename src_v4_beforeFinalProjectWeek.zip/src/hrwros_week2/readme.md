# hrwros_week2

## Overview

All files related to the Fanuc LR Mate 200iC (launch files, meshes and urdf/xacros) were copied from the [fanuc_lrmate200ic_support][] package from the [fanuc][] set of packages in [ROS-Industrial][] program.

The original license (BSD) still applies to those files.


[fanuc_lrmate200ic_support]: http://wiki.ros.org/fanuc_lrmate200ic_support
[ROS-Industrial]: http://wiki.ros.org/Industrial
[fanuc]: http://wiki.ros.org/fanuc
